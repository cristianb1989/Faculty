#ifndef __ARRAYIO
#define __ARRAYIO

	void read_array(int A[], int N);
	void print_array(int A[], int N);

#endif