#ifndef __ARRAYIO
#define __ARRAYIO

	void mergeSort(int A[], int begin, int end);

#endif