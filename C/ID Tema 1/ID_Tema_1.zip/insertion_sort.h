#ifndef __ARRAYIO
#define __ARRAYIO

	void insertionSort(int A[], int left, int right);

#endif